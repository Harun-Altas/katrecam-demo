KATRECAM VERCEL DEMO (3 sayfa)

index.html: Ana sayfa
/urunlerimiz: 19 kategori özet ekranı
/urun-detay: örnek cam balkon sayfası

Vercel: Framework Preset Other, Root Directory proje kökü, Build Command boş.

Uyarılar:
- Bu sürüm DEMO, gerçek referans veya katalog içeriklerinin tümünü içermez.
- 6 saniyelik hero.mp4 mevcut ama gerçek ürün çekimi değil.
- Harici stok görüntüler henüz lisans/ürün uyumu için doğrulanmamıştır.
- 19 kategoriden yalnızca Cam Balkon için örnek detay sayfası vardır. Diğer kategori kartları bilgi talebi için WhatsApp açar.
- robots.txt, HTML meta etiketi ve Vercel X-Robots-Tag ile indexleme kapatıldı. Yayına geçişte kaldırılmalıdır.
- Katrecam.com DNS alanına hiçbir işlem uygulanmamalıdır.
